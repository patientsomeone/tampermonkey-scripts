/* eslint-disable no-console */
/* Native Node Modules */
import {spawn} from "child_process";
import {platform} from "process";
import {rm} from "fs/promises";

const pathList = ["./package-lock.json", "./node_modules"];

const debug = false;
const debLog = (msg) => {
    if (!debug) {
        return;
    } else {
        return console.error(msg);
    }
};

/* Typings */
/* Sanitized "any" */
type anyStandard = string | number | boolean | anyObject;
/* Object Definitions */
type anyObject = {
    [key: string | number]: anyStandard;
};
type nodeColor = "black" | "red" | "green" | "yellow" | "blue" | "magenta" | "cyan" | "white" | "none";

const colorLog = (color: { bg: nodeColor; fg: nodeColor }, msg: anyStandard): void => {
    const colorCodes = {
        foreground: {
            black: "\x1b[30m",
            red: "\x1b[31m",
            green: "\x1b[32m",
            yellow: "\x1b[33m",
            blue: "\x1b[34m",
            magenta: "\x1b[35m",
            cyan: "\x1b[36m",
            white: "\x1b[37m",
            none: ""
        },
        background: {
            black: "\x1b[40m",
            red: "\x1b[41m",
            green: "\x1b[42m",
            yellow: "\x1b[43m",
            blue: "\x1b[44m",
            magenta: "\x1b[45m",
            cyan: "\x1b[46m",
            white: "\x1b[47m",
            none: ""
        },
        util: {
            reset: "\x1b[0m"
        }
    };

    const rs = colorCodes.util.reset;
    let fg = colorCodes.foreground.none;
    let bg = colorCodes.background.none;
    const dashes = [" "];

    if (color.hasOwnProperty("fg")) {
        fg = colorCodes.foreground[color.fg];
    }

    if (color.hasOwnProperty("bg")) {
        bg = colorCodes.background[color.bg];
    }

    if (typeof msg === "string") {
        const count = Math.round(100 - msg.length);
        for (let i = count; i >= 0; i -= 1) {
            dashes.push("-");
        }
        dashes.push(" ");
    }

    console.log(`${bg}${fg} ----- %s${dashes.join("")}${rs}`, msg);
};

const setLog = (color: { bg: nodeColor; fg: nodeColor }) => {
    return (msg: string) => {
        return colorLog(color, msg);
    };
};

const promiseLoop = async (
    data: anyObject | anyStandard[],
    forEach: (dataReturned: anyObject | anyStandard, key: string | number) => Promise<void>
) => {
    if (Array.isArray(data)) {
        const arr = data;
        for (let i = arr.length - 1; i >= 0; i -= 1) {
            const current = arr[i];

            debLog(current);

            await forEach(current, i).catch((err) => {
                console.error(err);

                return Promise.reject(err);
            });
        }
    } else if (typeof data === "object") {
        for (const key in data) {
            if (data.hasOwnProperty(key)) {
                const current = data[key] as anyObject;
                debLog(current);

                /** Process each object entry */
                if (typeof forEach === "function") {
                    await forEach(current, key).catch((err) => {
                        console.error(err);

                        return Promise.reject(err);
                    });
                }
            }
        }
    } else {
        console.error("Data Not Usable");
        debLog(data);
        return Promise.reject("Provided data is not an Array or Object");
    }

    return Promise.resolve();
};

const removeDirectory = (folderPath: string) => {
    const processError = (err: {message?: string}) => {
        if (err.message.indexOf("no such file or directory") >= 0) {
            debLog("removeFile.newPromise.processError.if.no_such_file");
            colorLog({bg: "yellow", fg: "black"}, `Folder ${folderPath} does not exist, continuing.`);
            return Promise.resolve();
        } else {
            debLog("removeFile.newPromise.processError.if.else.no_such_file");
            console.error(err);
            return Promise.reject(err);
        }
    };

    return rm(folderPath, {recursive: true, force: true}).catch((err: {message?: string}) => {
        return processError(err);
    });
};

const removeAll = async (allDirectories: string[]) => {
    colorLog({bg: "magenta", fg: "white"}, "Beginning environment cleanup");
    return await promiseLoop(allDirectories, (currentPath, key) => {
        /** Loop through each provided path */
        const thisPath = currentPath as string;

        return removeDirectory(thisPath)
            .then(() => {
                return Promise.resolve();
            })
            .catch((err) => {
                console.error(err);
                return Promise.reject(err);
            });
    })
        .then(() => {
            colorLog({bg: "magenta", fg: "white"}, "Successfully cleaned up environment");
            return Promise.resolve();
        })
        .catch((err) => {
            console.error(err);
            return Promise.reject(err);
        });
};

const pullMaster = (): Promise<void> => {
    colorLog({bg: "blue", fg: "white"}, "Pulling files from Master");
    return new Promise((resolve, reject) => {
        const command = "git";
        const process = spawn(command, ["pull", "origin", "master"], {stdio: ["ignore", "inherit", "inherit"]});

        process.on("exit", (code) => {
            colorLog({bg: "blue", fg: "white"}, "Successfully pulled from master");

            resolve();
        });
    });
};

const nodeInstall = (): Promise<void> => {
    colorLog(
        {bg: "cyan", fg: "black"},
        `Reinstalling Node Modules using ${platform.indexOf("win32") >= 0 ? "Windows Specific" : "Non-Windows"} methods`
    );
    return new Promise((resolve, reject) => {
        /* Windows specific NPM call */
        const command = platform.indexOf("win32") >= 0 ? "npm.cmd" : "npm";
        const process = spawn(command, ["install"], {stdio: ["ignore", "inherit", "inherit"]});

        process.on("exit", (code) => {
            colorLog({bg: "cyan", fg: "black"}, "Successfully installed Node Modulenode s");
            resolve();
        });
    });
};

colorLog({bg: "white", fg: "black"}, "Beginning Environment Reset");

const resetEnvironment = (): Promise<void> => {
    return removeAll(pathList)
        .then(async () => {
            return await pullMaster().catch((err: anyStandard) => {
                colorLog({bg: "red", fg: "white"}, "Failed to pull from master");
                colorLog({bg: "blue", fg: "white"}, err);
            });
        })
        .then(async () => {
            return await nodeInstall().catch((err: anyStandard) => {
                colorLog({bg: "red", fg: "white"}, "Failed to reinstall Node Packages");
                colorLog({bg: "none", fg: "none"}, err);
            });
        })
        .then(() => {
            colorLog({bg: "green", fg: "black"}, "Environment Reset Complete");
            return Promise.resolve();
        })
        .catch((err) => {
            colorLog({bg: "red", fg: "white"}, "Failed to reset environment");
            console.error(err);
            throw err;
        });
};

resetEnvironment()
    .then(() => {
        return Promise.resolve();
    })
    .catch((err) => {
        console.error(err);
        return Promise.reject(err);
    });;