/* eslint-disable no-console */
/* Native Node Modules */
import { exec, spawn } from "child_process";
import { reject } from "lodash";
import { platform } from "process";
import { StringDecoder } from "string_decoder";

/* Typings */
/* Sanitized "any" */
export type anyStandard = string | number | boolean | anyObject | string[];
/* Object Definitions */
export type anyObject = {
    [key: string]: anyStandard;
    [key: number]: anyStandard;
};
export type nodeColor = "black" | "red" | "green" | "yellow" | "blue" | "magenta" | "cyan" | "white" | "none";

export const colorLog = (color: { bg: nodeColor; fg: nodeColor }, msg: anyStandard): void => {
    const colorCodes = {
        foreground: {
            black: "\x1b[30m",
            red: "\x1b[31m",
            green: "\x1b[32m",
            yellow: "\x1b[33m",
            blue: "\x1b[34m",
            magenta: "\x1b[35m",
            cyan: "\x1b[36m",
            white: "\x1b[37m",
            none: ""
        },
        background: {
            black: "\x1b[40m",
            red: "\x1b[41m",
            green: "\x1b[42m",
            yellow: "\x1b[43m",
            blue: "\x1b[44m",
            magenta: "\x1b[45m",
            cyan: "\x1b[46m",
            white: "\x1b[47m",
            none: ""
        },
        util: {
            reset: "\x1b[0m"
        }
    };

    const rs = colorCodes.util.reset;
    let fg = colorCodes.foreground.none;
    let bg = colorCodes.background.none;
    const dashes = [" "];

    if (color.hasOwnProperty("fg")) {
        fg = colorCodes.foreground[color.fg];
    }

    if (color.hasOwnProperty("bg")) {
        bg = colorCodes.background[color.bg];
    }

    if (typeof msg === "string") {
        const count = Math.round(100 - msg.length);
        for (let i = count; i >= 0; i -= 1) {
            dashes.push("-");
        }
        dashes.push(" ");
    }

    console.log(`${bg}${fg} ----- %s${dashes.join("")}${rs}`, msg);
};

const setLog = (color: { bg: nodeColor; fg: nodeColor }) => {
    return (msg: string) => {
        return colorLog(color, msg);
    };
};

const decoder = new StringDecoder("utf8");

declare var process: {
    env: NodeJS.ProcessEnv;
    argv: string[];
    [key: string]: anyStandard;
};

/* Define Version of Node */
const requiredVersion = "14.20.0";

export const setNode = (args: string[]): Promise<void> => {
    const ver = args[2];
    const clean = args[3] === "reset";
    const goalVersion = parseInt(ver.split(".")[0], 10);

    console.log(args);

    const global = {
        checkNodeVersion: () => {
            const log = setLog({ bg: "magenta", fg: "white" });
            return new Promise((resolve: (value: string) => void, reject) => {
                log("Checking Node Version");
                const command = "node";
                const spawnProcess = spawn(command, ["--version"], { stdio: ["ignore", "pipe", "inherit"] });
                const decoder = new StringDecoder("utf8");
                let compatibleVersion = "";

                spawnProcess.stdout.on("data", (data: Buffer) => {
                    const decodedData = decoder.write(data).trim();
                    const currentVersion = decodedData.split("v").join("");
                    const needsUpdate = parseInt(currentVersion.split(".")[0], 10) < goalVersion;

                    if (!needsUpdate) {
                        compatibleVersion = currentVersion;
                    }

                    log(`Current Node Version: ${currentVersion}; Required Version ${goalVersion}.x or higher`);
                    log(`Current Node Version is ${needsUpdate ? "Outdated" : "Up to Date"}`);
                });

                spawnProcess.on("close", (code) => {
                    log("Completed checking Node version");
                    resolve(compatibleVersion);
                });
            });
        }
    };

    const unix = {
        setNvmPaths: (path: string, nodeVersion: string) => {
            const pathArr = path.split(":");
            const newPath = [];

            const checkAndAdd = (originalPath: string) => {
                const replacer = /v\d\d?.\d\d?.\d\d?/;
                const newVersion = `v${nodeVersion}`;

                for (let i = newPath.length - 1; i >= 0; i -= 1) {
                    const current = newPath[i];
                    if (current.indexOf(".nvm/versions/node") >= 0) {
                        return;
                    }
                }

                newPath.push(originalPath.replace(replacer, newVersion));
            };

            for (let i = pathArr.length - 1; i >= 0; i -= 1) {
                const current = pathArr[i];

                if (current.indexOf(".nvm/versions/node") < 0) {
                    newPath.push(current);
                } else {
                    checkAndAdd(current);
                }
            }

            return newPath.join(":");
        },
        checkNvm: () => {
            const log = setLog({ bg: "black", fg: "white" });
            return new Promise((resolve: (value: boolean) => void, reject) => {
                log("Attempting to set NVM Version");
                const command = `echo`;
                const version = "v14.20.0";

                const currentEnv = process.env;
                currentEnv.NVM_BIN = `/Users/sea-robinsjp-m/.nvm/versions/node/${version}/bin`;
                currentEnv.NVM_INC = `/Users/sea-robinsjp-m/.nvm/versions/node/${version}/bin/include/node`;
                currentEnv.PATH = unix.setNvmPaths(currentEnv.PATH, version);

                const spawnProcess = spawn(command, [process.env.NVM_BIN], {
                    stdio: ["ignore", "inherit", "inherit"],
                    env: currentEnv
                });

                const decoder = new StringDecoder("utf8");

                spawnProcess.on("error", (data: Buffer) => {
                    // const decodedData = decoder.write(data).trim();

                    // log("NVM may not be installed");
                    console.error(data);
                    reject("NVM may not be installed");
                });

                spawnProcess.on("close", (code) => {
                    log(process.env.NVM_BIN);

                    global
                        .checkNodeVersion()
                        .then((nodeVersion: string) => {
                            if (nodeVersion === version) {
                                log("Successfully Changed Node Version");
                                resolve(true);
                            } else {
                                log("Failed to change Node Version");
                                log(`Node Version: ${nodeVersion}`);
                                log(`Needed Version: ${version}`);
                                log(`NVM_BIN ${process.env.NVM_BIN}`);
                                reject(`Node version ${nodeVersion} does not match needed version ${nodeVersion}`);
                            }
                        })
                        .catch((err) => {
                            reject(err);
                        });
                });
            });
        },

        nvmExecutable: () => {
            return new Promise((resolve: (value?: void) => void, reject) => {
                const log = setLog({ bg: "white", fg: "black" });
                const command = "chmod";
                const bashProcess = spawn(command, ["777", `~/.nvm/nvm.sh`], {
                    stdio: ["ignore", "pipe", "pipe"]
                });

                bashProcess.stdout.on("data", (data: Buffer) => {
                    const decodedData = decoder.write(data).trim();

                    log(decodedData);
                });

                bashProcess.stdout.on("error", (err) => {
                    colorLog({ bg: "red", fg: "white" }, `${command} nvmExecutable ERROR: ${err}`);
                });

                bashProcess.on("close", (code) => {
                    const codes = {
                        127: "Command not found"
                    };

                    const exitCode = codes[code.toString()];

                    if (codes.hasOwnProperty(exitCode)) {
                        colorLog({ bg: "red", fg: "white" }, `${command} nvmExecutable ERROR: ${exitCode}`);
                        reject(exitCode);
                    }

                    log(`${command} nvmExecutable complete`);
                    log(`Exit Code: ${code}`);
                    resolve();
                });
            });
        },

        setNvmExecutable: () => {
            return new Promise((resolve: (value?: void) => void, reject) => {
                const log = setLog({ bg: "white", fg: "black" });
                const command = "chmod";
                const bashProcess = spawn(command, ["777", `${__dirname}/setNvm.sh`], {
                    stdio: ["ignore", "pipe", "pipe"]
                });

                bashProcess.stdout.on("data", (data: Buffer) => {
                    const decodedData = decoder.write(data).trim();

                    log(decodedData);
                });

                bashProcess.stdout.on("error", (err) => {
                    colorLog({ bg: "red", fg: "white" }, `${command} setNvm ERROR: ${err}`);
                });

                bashProcess.on("close", (code) => {
                    const codes = {
                        127: "Command not found"
                    };

                    const exitCode = codes[code.toString()];

                    if (codes.hasOwnProperty(exitCode)) {
                        colorLog({ bg: "red", fg: "white" }, `${command} setNvm ERROR: ${exitCode}`);
                        reject(exitCode);
                    }

                    log(`${command} setNvm complete`);
                    log(`Exit Code: ${code}`);
                    resolve();
                });
            });
        },
        checkAndUpdate: () => {
            return new Promise((resolve: (value?: void) => void, reject) => {
                const log = setLog({ bg: "white", fg: "black" });
                const command = "bash";
                const bashProcess = spawn(command, [`${__dirname}/setNvm.sh`], {
                    stdio: ["ignore", "pipe", "inherit"]
                });

                bashProcess.stdout.on("data", (data: Buffer) => {
                    const decodedData = decoder.write(data).trim();

                    log(decodedData);
                });

                bashProcess.stdout.on("error", (err) => {
                    colorLog({ bg: "red", fg: "white" }, `ERROR: ${err}`);
                });

                bashProcess.on("close", (code) => {
                    const codes = {
                        127: "Command not found"
                    };

                    const exitCode = codes[code.toString()];

                    if (codes.hasOwnProperty(exitCode)) {
                        colorLog({ bg: "red", fg: "white" }, `ERROR: ${exitCode}`);
                        reject(exitCode);
                    }

                    log("Environment reset, have a nice day!");
                    log(`Exit Code: ${code}`);
                    resolve();
                });
            });
        }
    };

    const windows = {
        install: (version: string) => {
            const log = setLog({ bg: "cyan", fg: "black" });
            return new Promise((resolve: (value: string) => void, reject) => {
                log(`Installing Node ${version}`);
                const command = "nvm";
                const spawnProcess = spawn(command, ["install", version], { stdio: ["ignore", "inherit", "inherit"] });

                spawnProcess.on("close", (code) => {
                    log(`Successfully installed Node ${version}`);
                    resolve(version);
                });
            });
        },

        use: (version: string) => {
            const log = setLog({ bg: "blue", fg: "white" });
            return new Promise((resolve, reject) => {
                log(`Using Node ${version}`);
                const command = "nvm";
                const spawnProcess = spawn(command, ["use", version], { stdio: ["ignore", "inherit", "inherit"] });

                spawnProcess.on("close", (code) => {
                    resolve(true);
                });
            });
        },

        nvmList: () => {
            const log = setLog({ bg: "white", fg: "black" });
            return new Promise((resolve: (value: string) => void, reject) => {
                log("Fetching Available Node Versions");
                const command = "nvm";
                const spawnProcess = spawn(command, ["list"], { stdio: ["ignore", "pipe", "inherit"] });
                const decoder = new StringDecoder("utf8");
                let neededVersion = "";

                spawnProcess.stdout.on("data", (data: Buffer) => {
                    const decodedData = decoder.write(data).trim();

                    if (!!decodedData) {
                        const versionList = decodedData.split("\n");

                        /* Sanitize and Store version list */
                        for (let i = versionList.length - 1; i >= 0; i -= 1) {
                            const current = versionList[i];
                            const regexp = /\d\d?\.\d\d?\.\d\d?/g;
                            const sanitized = current.match(regexp)[0];

                            if (sanitized === ver) {
                                log("Exact required version availabile");
                                neededVersion = sanitized;
                            }

                            log(`Node Version from NVM: ${sanitized}`);
                        }
                    }
                });

                spawnProcess.on("close", (code) => {
                    log("Completed fetching Node versions");

                    if (!!neededVersion) {
                        log("Required Version Available");
                        resolve(neededVersion);
                    } else {
                        log("Required Version unavailable, installing");
                        windows
                            .install(ver)
                            .then((installedVersion) => {
                                log(`Installed Node ${installedVersion}`);
                                resolve(installedVersion);
                            })
                            .catch((err) => {
                                console.error(err);
                                reject(err);
                            });
                    }
                });
            });
        },

        checkNvm: (): Promise<boolean> => {
            const log = setLog({ bg: "black", fg: "white" });
            return new Promise((resolve, reject) => {
                const command = `nvm`;

                const spawner = spawn(command, ["version"], { stdio: ["ignore", "inherit", "inherit"] });
                const decoder = new StringDecoder("utf8");

                spawner.on("error", (data: Buffer) => {
                    console.error(data);
                    reject("NVM may not be installed");
                });

                spawner.on("close", (code) => {
                    log("NVM Available");
                    resolve(true);
                });
            });
        },

        installNvm: () => {
            const log = setLog({ bg: "yellow", fg: "black" });
            return new Promise((resolve, reject) => {
                log("Attempting to install NVM");
                const isWindows = platform.indexOf("Win32") >= 0;

                if (isWindows) {
                    log("Unable to install NVM for Windows");
                    log("Please use nvm-setup.exe at https://github.com/coreybutler/nvm-windows/releases");
                    return reject("Unable to install NVM for Windows");
                }

                const command = "curl";
                const spawnProcess = spawn(
                    command,
                    ["-o-", "https://raw.githubusercontent.com/nvm-sh/nvm/v0.39.1/install.sh", "|", "bash"],
                    { stdio: ["ignore", "inherit", "inherit"] }
                );

                spawnProcess.on("error", (data: Buffer) => {
                    const decodedData = decoder.write(data).trim();

                    log("NVM could not be installed");

                    reject("NVM could not be installed");
                });

                spawnProcess.on("close", (code) => {
                    log("NVM Available");
                    windows
                        .checkNvm()
                        .then((data) => {
                            resolve(data);
                        })
                        .catch((err) => {
                            console.error(err);
                            reject(err);
                        });
                });
            });
        },

        updateNodeVersion: () => {
            const log = setLog({ bg: "green", fg: "white" });
            return windows
                .checkNvm()
                .then((isAvailable: boolean) => {
                    if (isAvailable) {
                        return windows.nvmList();
                    } else {
                        return windows
                            .installNvm()
                            .then(windows.nvmList)
                            .catch((err) => {
                                console.error(err);
                                return Promise.reject(err);
                            });
                    }
                })
                .then((requiredVersion) => {
                    return windows.use(requiredVersion);
                })
                .catch((err) => {
                    console.error(err);
                    return Promise.reject(err);
                });
        },

        checkAndUpdate: () => {
            return new Promise((resolve: (value?: void) => void, reject) => {
                const log = setLog({ bg: "white", fg: "black" });
                const command = "sh";
                const spawnProcess = spawn(command, ["./bin/resetEnv/setNvm.bat"], {
                    stdio: ["ignore", "inherit", "inherit"]
                });

                spawnProcess.on("close", (code) => {
                    log("Environment reset, have a nice day!");
                    resolve();
                });
            });
        }
    };

    const resetEnvironment = () => {
        const log = setLog({ bg: "white", fg: "black" });
        return new Promise((resolve: (value?: void) => void, reject) => {
            log("Executing Reset");
            const command = "node";
            const spawnProcess = spawn(command, ["./bin/resetEnv/resetEnv"], {
                stdio: ["ignore", "inherit", "inherit"]
            });

            spawnProcess.on("close", (code) => {
                log("Environment reset, have a nice day!");
                resolve();
            });
        });
    };

    const init = () => {
        const system = platform.indexOf("Win32") >= 0 ? windows : unix;

        return system.checkAndUpdate();

        // return [system].checkNodeVersion()
        //     .then((version) => {
        //         if (!version) {
        //             return updateNodeVersion();
        //         } else {
        //             return Promise.resolve(version);
        //         }
        //     })
        //     .then(() => {
        //         if (clean) {
        //             return resetEnvironment();
        //         }
        //     })
        //     .then(() => {
        //         return Promise.resolve();
        //     })
        //     .catch((err) => {
        //         console.error(err);
        //         return Promise.reject(err);
        //     });

        // return unix
        //     .checkNvm()
        //     .then(() => {
        //         return resetEnvironment();
        //     })
        //     .catch((err) => {
        //         console.error(err);
        //         return Promise.reject(err);
        //     });
    };

    return init()
        .then(() => {
            return Promise.resolve();
        })
        .catch((err) => {
            reject(err);
        });
};

if (process.argv.length > 2) {
    setNode(process.argv)
        .then((data) => {
            // eslint-disable-next-line no-console
            colorLog({ bg: "green", fg: "black" }, "Complete");
            return Promise.resolve(data);
        })
        .catch((err) => {
            console.error(err);
        });
} else {
    colorLog({ bg: "yellow", fg: "black" }, "Executing Test Version");
    const testArgs = process.argv;
    testArgs.push("14.20.0");
    testArgs.push("reset");

    setNode(process.argv)
        .then((data) => {
            // eslint-disable-next-line no-console
            colorLog({ bg: "green", fg: "black" }, "Complete");
            return Promise.resolve(data);
        })
        .catch((err) => {
            console.error(err);
        });
}
