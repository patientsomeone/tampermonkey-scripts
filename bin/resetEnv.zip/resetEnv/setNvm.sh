#!/bin/sh
. ~/.nvm/nvm.sh
. ~/.profile
. ~/.bashrc

VER=($(node --version | tr "." " " | tr "v" " "))
INTENDED=14

echo "Current Node Version"
echo $(node --version)


if [ $VER -ge $INTENDED ]
then
    echo $(node --version) is over 14
else
    echo $(node --version) is outdated. Updating
    (nvm use $INTENDED || echo Node version $INTENDED not available, installing --success=first)  || nvm install $INTENDED && nvm use $INTENDED
    nvm alias default $INTENDED
    wait
fi

echo "Node Version"
    node --version

node ./bin/resetEnv/resetEnv