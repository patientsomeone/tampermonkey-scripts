#!/bin/sh
. ~/.nvm/nvm.sh
# . ~/.profile
# . ~/.bashrc

echo Beginning Environment Cleanup
intendedNodeVersion=$1;
shift;
files=("${@}");

# echo Initial Node Version: $(node --version);
# echo Available Node Versions: $availableVersions;

# echo Intendend Node Version: $intendedNodeVersion
echo Files to delete: ${files[@]}
# echo Files to delete: $files

# Returns 0 if Node Version is compatible
versionCompatible() {
    ver=($(node --version | tr "." " " | tr "v" " "));
    isCompatible=false

    echo ------ ------
    echo Checking Node Version Compatibility
    # echo $ver

    if [ $ver -ge $intendedNodeVersion ];
    then
        echo $(node --version) is equal to or above 14;
        isCompatible=true
    else
        echo $(node --version) is outdated. Updating;
        wait
        isCompatible=false
    fi

    # echo Is Compatible: $isCompatible
    echo ------ ------
}

# Returns 0 if Node Version is available in NVM List
versionAvailable() {
    echo ------ ------
    isAvailable=false
    
    availableVersions=($(nvm list));
    wait
    
    echo Checking for Node version $intendedNodeVersion;
    # echo $availableVersions[@]

    for i in "${availableVersions[@]}"
    do :
        # echo Available Version: $i;

        currentAvailable=($(echo "$i" | tr "." " " | tr "v" " "));

        # echo Current Version Number: $currentAvailable;

        if [ $currentAvailable = $intendedNodeVersion ]; 
        then
            echo Matching Version Available: $i;
            isAvailable=true;
        fi
        wait
    done
    wait
    echo ------ ------
}

installNodeVersion() {
    echo ------ ------
    echo Installing Node version $intendedNodeVersion
    nvm install $intendedNodeVersion
    wait

    versionCompatible
    wait
    echo ------ ------
}

setNodeVersion() {
    echo ------ ------
    echo Setting node version $intendedNodeVersion
    nvm use $intendedNodeVersion
    wait

    nvm alias default $intendedNodeVersion
    wait
    echo ------ ------
}

runNvm() {
    echo ------ ------
    versionAvailable
    wait

    if [ $isAvailable = true ]
    then
        # echo runNvm Setting
        setNodeVersion
        wait
    else
        # echo runNvm installing
        installNodeVersion
        wait
    fi
    echo ------ ------
}

checkNode() {
    echo ------
    echo Checking current Node version
    versionCompatible

    updateNode=true
    
    if [ $isCompatible = true ]
    then
        echo Current Node Version $(node --version) is compatible
        updateNode=false
    else
        echo Updating Node Version from $(node --version)
        runNvm
        wait
        versionCompatible

        if [ $isCompatible = true ]
        then
            echo Successfully updated Node Version
            wait
            updateNode=false
        else
            echo Node Version Update Failed. Please retry, or install Node version $intendedNodeVersion manually
            wait
            updateNode=true
        fi
    fi
    
    echo ------
}

removeFiles() {
    echo ------
    echo Preparing to remove: ${files[@]}
    for i in "${files[@]}"
    do :
        echo Checking for $i;

        if [ -f $i ] || [ -d $i ]; 
        then
            echo Removing $i;
            rm -r $i;
        else 
            echo $i does not exist;
        fi
        wait
    done
    wait
    echo ------
}

stash() {
    echo ------
    echo Stashing any changes to repo;
    git stash;
    wait
    echo ------
}

stashPop() {
    echo ------
    echo Popping stashed changes;
    git stash pop;
    wait
    echo ------
}

checkGit() {
    echo ------
    status=$(git status);
    wait

    echo $(grep "ahead of 'origin/master'" <<< "$status" | wc -l)
    echo $(grep -- "to be committed" <<< "$status"  | wc -l)

    if [ $(grep "ahead of 'origin/master'" <<< "$status" | wc -l) -ge 1 ] || [ $(grep "to be committed" <<< "$status" | wc -l) -ge 1 ] 
    then 
        echo needs stash and pop
        return 0
    fi

    return 1;
    echo ------
}

pullMaster() {
    echo ------
    echo Pulling from Master;
    (git pull origin master --no-rebase || echo Unable to pull from Master --success=first) && echo Successfully Pulled from Master;
    wait
    echo ------
}

installModules() {
    echo ------
    echo Reinstalling Node Modules
    npm i
    wait
    echo ------
}

removeFiles
wait

pullMaster
wait

checkNode
wait

installModules
wait

echo Reset Complete