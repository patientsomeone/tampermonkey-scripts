/* eslint-disable no-console */
/* Native Node Modules */
import { exec, spawn } from "child_process";
import { reject } from "lodash";
import { platform } from "process";
import { StringDecoder } from "string_decoder";

/* Typings */
/* Sanitized "any" */
export type anyStandard = string | number | boolean | anyObject | string[];
/* Object Definitions */
export type anyObject = {
    [key: string]: anyStandard;
    [key: number]: anyStandard;
};
export type nodeColor = "black" | "red" | "green" | "yellow" | "blue" | "magenta" | "cyan" | "white" | "none";

export const colorLog = (color: { bg: nodeColor; fg: nodeColor }, msg: anyStandard): void => {
    const colorCodes = {
        foreground: {
            black: "\x1b[30m",
            red: "\x1b[31m",
            green: "\x1b[32m",
            yellow: "\x1b[33m",
            blue: "\x1b[34m",
            magenta: "\x1b[35m",
            cyan: "\x1b[36m",
            white: "\x1b[37m",
            none: ""
        },
        background: {
            black: "\x1b[40m",
            red: "\x1b[41m",
            green: "\x1b[42m",
            yellow: "\x1b[43m",
            blue: "\x1b[44m",
            magenta: "\x1b[45m",
            cyan: "\x1b[46m",
            white: "\x1b[47m",
            none: ""
        },
        util: {
            reset: "\x1b[0m"
        }
    };

    const rs = colorCodes.util.reset;
    let fg = colorCodes.foreground.none;
    let bg = colorCodes.background.none;
    const dashes = [" "];

    if (color.hasOwnProperty("fg")) {
        fg = colorCodes.foreground[color.fg];
    }

    if (color.hasOwnProperty("bg")) {
        bg = colorCodes.background[color.bg];
    }

    if (typeof msg === "string") {
        const count = Math.round(100 - msg.length);
        for (let i = count; i >= 0; i -= 1) {
            dashes.push("-");
        }
        dashes.push(" ");
    }

    console.log(`${bg}${fg} ----- %s${dashes.join("")}${rs}`, msg);
};

const setLog = (color: { bg: nodeColor; fg: nodeColor }) => {
    return (msg: string) => {
        return colorLog(color, msg);
    };
};

const decoder = new StringDecoder("utf8");

const isWindows = platform.indexOf("Win32") >= 0;



declare var process: {
    env: NodeJS.ProcessEnv;
    argv: string[];
    [key: string]: anyStandard;
};

/* Define Version of Node */
const requiredVersion = "14.20.0";

const unix = {
    shExe: () => {
        return new Promise((resolve: (value?: void) => void, reject) => {
            const log = setLog({ bg: "white", fg: "black" });
            const command = "chmod";
            const bashProcess = spawn(command, ["777", `${__dirname}/resetEnv.sh`], {
                stdio: ["ignore", "pipe", "pipe"]
            });

            bashProcess.stdout.on("data", (data: Buffer) => {
                const decodedData = decoder.write(data).trim();

                console.log(decodedData);
            });

            bashProcess.stdout.on("error", (err) => {
                colorLog({ bg: "red", fg: "white" }, `${command} setNvm ERROR: ${err}`);
            });

            bashProcess.on("close", (code) => {
                const codes = {
                    127: "Command not found"
                };

                const exitCode = codes[code.toString()];

                if (codes.hasOwnProperty(exitCode)) {
                    colorLog({ bg: "red", fg: "white" }, `${command} setNvm ERROR: ${exitCode}`);
                    reject(exitCode);
                }

                log(`resetEnv.sh set as executable`);
                // log(`Exit Code: ${code}`);
                resolve();
            });
        });
    },
    runSh: (receivedArguments: string[]) => {
        return new Promise((resolve: (value?: void) => void, reject) => {
            const log = setLog({ bg: "white", fg: "black" });
            const command = "bash";

            receivedArguments.unshift(`${__dirname}/resetEnv.bat`);

            const bashProcess = spawn(command, receivedArguments, {
                stdio: ["ignore", "ignore", "pipe"]
            });

            bashProcess.stdout.on("data", (data: Buffer) => {
                const decodedData = decoder.write(data).trim();

                console.log(decodedData);
            });

            bashProcess.stdout.on("error", (err) => {
                colorLog({ bg: "red", fg: "white" }, `${command} setNvm ERROR: ${err}`);
            });

            bashProcess.on("close", (code) => {
                const codes = {
                    127: "Command not found"
                };

                const exitCode = codes[code.toString()];

                if (codes.hasOwnProperty(exitCode)) {
                    colorLog({ bg: "red", fg: "white" }, `${command} setNvm ERROR: ${exitCode}`);
                    reject(exitCode);
                }

                log(`Environment reset complete! Enjoy your clean Environment!`);
                // log(`Exit Code: ${code}`);
                resolve();
            });
        });
    },
    resetEnv: (argArray) => {
        return unix
            .shExe()
            .then(() => {
                unix.runSh(argArray);
            })
            .catch((err) => {
                console.error(err);
                /* Do Work */
                return Promise.reject(err);
            });
    }
};

const windows = {
    resetEnv: (...arg) => {
        return new Promise((resolve: (value?: void) => void, reject) => {
            const log = setLog({ bg: "white", fg: "black" });
            const command = "cmd.exe";
            const bashProcess = spawn(`${__dirname}/resetEnv.bat`, [], {
                stdio: ["ignore", "pipe", "pipe"]
            });

            bashProcess.stdout.on("data", (data: Buffer) => {
                const decodedData = decoder.write(data).trim();

                console.log(decodedData);
            });

            bashProcess.stdout.on("error", (err) => {
                colorLog({ bg: "red", fg: "white" }, `${command} setNvm ERROR: ${err}`);
            });

            bashProcess.on("close", (code) => {
                const codes = {
                    127: "Command not found"
                };

                const exitCode = codes[code.toString()];

                if (codes.hasOwnProperty(exitCode)) {
                    colorLog({ bg: "red", fg: "white" }, `${command} setNvm ERROR: ${exitCode}`);
                    reject(exitCode);
                }

                log(`${command} setNvm complete`);
                log(`Exit Code: ${code}`);
                resolve();
            });
        });
    }
};

const init = (args) => {
    const system = platform.indexOf("Win32") >= 0 ? windows : unix;

    return system.resetEnv(args)
        .then(() => {
            colorLog({bg: "green", fg: "white"}, "Environment Reset complete! Have a great day!")
            return Promise.resolve();
        })
        .catch((err) => {
            console.error(err);
            colorLog({ bg: "red", fg: "white" }, "Environment Reset Failed...");
            colorLog({ bg: "red", fg: "white" }, err);
            return Promise.reject(err);
        });
};


// init();

if (process.argv.length > 2) {
    init(process.argv.slice(2))
} else {
    colorLog({ bg: "yellow", fg: "black" }, "Executing Test Version");
    const testArgs = ["14", "./package-lock.json", "./node_modules"];

    init(testArgs)
}