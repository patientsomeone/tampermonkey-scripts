"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.colorLog = void 0;
/* eslint-disable no-console */
/* Native Node Modules */
const child_process_1 = require("child_process");
const process_1 = require("process");
const string_decoder_1 = require("string_decoder");
const colorLog = (color, msg) => {
    const colorCodes = {
        foreground: {
            black: "\x1b[30m",
            red: "\x1b[31m",
            green: "\x1b[32m",
            yellow: "\x1b[33m",
            blue: "\x1b[34m",
            magenta: "\x1b[35m",
            cyan: "\x1b[36m",
            white: "\x1b[37m",
            none: ""
        },
        background: {
            black: "\x1b[40m",
            red: "\x1b[41m",
            green: "\x1b[42m",
            yellow: "\x1b[43m",
            blue: "\x1b[44m",
            magenta: "\x1b[45m",
            cyan: "\x1b[46m",
            white: "\x1b[47m",
            none: ""
        },
        util: {
            reset: "\x1b[0m"
        }
    };
    const rs = colorCodes.util.reset;
    let fg = colorCodes.foreground.none;
    let bg = colorCodes.background.none;
    const dashes = [" "];
    if (color.hasOwnProperty("fg")) {
        fg = colorCodes.foreground[color.fg];
    }
    if (color.hasOwnProperty("bg")) {
        bg = colorCodes.background[color.bg];
    }
    if (typeof msg === "string") {
        const count = Math.round(100 - msg.length);
        for (let i = count; i >= 0; i -= 1) {
            dashes.push("-");
        }
        dashes.push(" ");
    }
    console.log(`${bg}${fg} ----- %s${dashes.join("")}${rs}`, msg);
};
exports.colorLog = colorLog;
const setLog = (color) => {
    return (msg) => {
        return (0, exports.colorLog)(color, msg);
    };
};
const decoder = new string_decoder_1.StringDecoder("utf8");
const isWindows = process_1.platform.indexOf("Win32") >= 0;
/* Define Version of Node */
const requiredVersion = "14.20.0";
const unix = {
    shExe: () => {
        return new Promise((resolve, reject) => {
            const log = setLog({ bg: "white", fg: "black" });
            const command = "chmod";
            const bashProcess = (0, child_process_1.spawn)(command, ["777", `${__dirname}/resetEnv.sh`], {
                stdio: ["ignore", "pipe", "pipe"]
            });
            bashProcess.stdout.on("data", (data) => {
                const decodedData = decoder.write(data).trim();
                console.log(decodedData);
            });
            bashProcess.stdout.on("error", (err) => {
                (0, exports.colorLog)({ bg: "red", fg: "white" }, `${command} setNvm ERROR: ${err}`);
            });
            bashProcess.on("close", (code) => {
                const codes = {
                    127: "Command not found"
                };
                const exitCode = codes[code.toString()];
                if (codes.hasOwnProperty(exitCode)) {
                    (0, exports.colorLog)({ bg: "red", fg: "white" }, `${command} setNvm ERROR: ${exitCode}`);
                    reject(exitCode);
                }
                log(`resetEnv.sh set as executable`);
                // log(`Exit Code: ${code}`);
                resolve();
            });
        });
    },
    runSh: (receivedArguments) => {
        return new Promise((resolve, reject) => {
            const log = setLog({ bg: "white", fg: "black" });
            const command = "bash";
            receivedArguments.unshift(`${__dirname}/resetEnv.bat`);
            const bashProcess = (0, child_process_1.spawn)(command, receivedArguments, {
                stdio: ["ignore", "ignore", "pipe"]
            });
            bashProcess.stdout.on("data", (data) => {
                const decodedData = decoder.write(data).trim();
                console.log(decodedData);
            });
            bashProcess.stdout.on("error", (err) => {
                (0, exports.colorLog)({ bg: "red", fg: "white" }, `${command} setNvm ERROR: ${err}`);
            });
            bashProcess.on("close", (code) => {
                const codes = {
                    127: "Command not found"
                };
                const exitCode = codes[code.toString()];
                if (codes.hasOwnProperty(exitCode)) {
                    (0, exports.colorLog)({ bg: "red", fg: "white" }, `${command} setNvm ERROR: ${exitCode}`);
                    reject(exitCode);
                }
                log(`Environment reset complete! Enjoy your clean Environment!`);
                // log(`Exit Code: ${code}`);
                resolve();
            });
        });
    },
    resetEnv: (argArray) => {
        return unix
            .shExe()
            .then(() => {
            unix.runSh(argArray);
        })
            .catch((err) => {
            console.error(err);
            /* Do Work */
            return Promise.reject(err);
        });
    }
};
const windows = {
    resetEnv: (...arg) => {
        return new Promise((resolve, reject) => {
            const log = setLog({ bg: "white", fg: "black" });
            const command = "cmd.exe";
            const bashProcess = (0, child_process_1.spawn)(`${__dirname}/resetEnv.bat`, [], {
                stdio: ["ignore", "pipe", "pipe"]
            });
            bashProcess.stdout.on("data", (data) => {
                const decodedData = decoder.write(data).trim();
                console.log(decodedData);
            });
            bashProcess.stdout.on("error", (err) => {
                (0, exports.colorLog)({ bg: "red", fg: "white" }, `${command} setNvm ERROR: ${err}`);
            });
            bashProcess.on("close", (code) => {
                const codes = {
                    127: "Command not found"
                };
                const exitCode = codes[code.toString()];
                if (codes.hasOwnProperty(exitCode)) {
                    (0, exports.colorLog)({ bg: "red", fg: "white" }, `${command} setNvm ERROR: ${exitCode}`);
                    reject(exitCode);
                }
                log(`${command} setNvm complete`);
                log(`Exit Code: ${code}`);
                resolve();
            });
        });
    }
};
const init = (args) => {
    const system = process_1.platform.indexOf("Win32") >= 0 ? windows : unix;
    return system.resetEnv(args);
};
// init();
if (process.argv.length > 2) {
    init(process.argv.slice(2));
}
else {
    (0, exports.colorLog)({ bg: "yellow", fg: "black" }, "Executing Test Version");
    const testArgs = ["14", "./package-lock.json", "./node_modules"];
    init(testArgs);
}
