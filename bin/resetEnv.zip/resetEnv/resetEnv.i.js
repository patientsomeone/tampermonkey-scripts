"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
/* eslint-disable no-console */
/* Native Node Modules */
const child_process_1 = require("child_process");
const process_1 = require("process");
const promises_1 = require("fs/promises");
const pathList = ["./package-lock.json", "./node_modules"];
const debug = false;
const debLog = (msg) => {
    if (!debug) {
        return;
    }
    else {
        return console.error(msg);
    }
};
const colorLog = (color, msg) => {
    const colorCodes = {
        foreground: {
            black: "\x1b[30m",
            red: "\x1b[31m",
            green: "\x1b[32m",
            yellow: "\x1b[33m",
            blue: "\x1b[34m",
            magenta: "\x1b[35m",
            cyan: "\x1b[36m",
            white: "\x1b[37m",
            none: ""
        },
        background: {
            black: "\x1b[40m",
            red: "\x1b[41m",
            green: "\x1b[42m",
            yellow: "\x1b[43m",
            blue: "\x1b[44m",
            magenta: "\x1b[45m",
            cyan: "\x1b[46m",
            white: "\x1b[47m",
            none: ""
        },
        util: {
            reset: "\x1b[0m"
        }
    };
    const rs = colorCodes.util.reset;
    let fg = colorCodes.foreground.none;
    let bg = colorCodes.background.none;
    const dashes = [" "];
    if (color.hasOwnProperty("fg")) {
        fg = colorCodes.foreground[color.fg];
    }
    if (color.hasOwnProperty("bg")) {
        bg = colorCodes.background[color.bg];
    }
    if (typeof msg === "string") {
        const count = Math.round(100 - msg.length);
        for (let i = count; i >= 0; i -= 1) {
            dashes.push("-");
        }
        dashes.push(" ");
    }
    console.log(`${bg}${fg} ----- %s${dashes.join("")}${rs}`, msg);
};
const setLog = (color) => {
    return (msg) => {
        return colorLog(color, msg);
    };
};
const promiseLoop = (data, forEach) => __awaiter(void 0, void 0, void 0, function* () {
    if (Array.isArray(data)) {
        const arr = data;
        for (let i = arr.length - 1; i >= 0; i -= 1) {
            const current = arr[i];
            debLog(current);
            yield forEach(current, i).catch((err) => {
                console.error(err);
                return Promise.reject(err);
            });
        }
    }
    else if (typeof data === "object") {
        for (const key in data) {
            if (data.hasOwnProperty(key)) {
                const current = data[key];
                debLog(current);
                /** Process each object entry */
                if (typeof forEach === "function") {
                    yield forEach(current, key).catch((err) => {
                        console.error(err);
                        return Promise.reject(err);
                    });
                }
            }
        }
    }
    else {
        console.error("Data Not Usable");
        debLog(data);
        return Promise.reject("Provided data is not an Array or Object");
    }
    return Promise.resolve();
});
const removeDirectory = (folderPath) => {
    const processError = (err) => {
        if (err.message.indexOf("no such file or directory") >= 0) {
            debLog("removeFile.newPromise.processError.if.no_such_file");
            colorLog({ bg: "yellow", fg: "black" }, `Folder ${folderPath} does not exist, continuing.`);
            return Promise.resolve();
        }
        else {
            debLog("removeFile.newPromise.processError.if.else.no_such_file");
            console.error(err);
            return Promise.reject(err);
        }
    };
    return (0, promises_1.rm)(folderPath, { recursive: true, force: true }).catch((err) => {
        return processError(err);
    });
};
const removeAll = (allDirectories) => __awaiter(void 0, void 0, void 0, function* () {
    colorLog({ bg: "magenta", fg: "white" }, "Beginning environment cleanup");
    return yield promiseLoop(allDirectories, (currentPath, key) => {
        /** Loop through each provided path */
        const thisPath = currentPath;
        return removeDirectory(thisPath)
            .then(() => {
            return Promise.resolve();
        })
            .catch((err) => {
            console.error(err);
            return Promise.reject(err);
        });
    })
        .then(() => {
        colorLog({ bg: "magenta", fg: "white" }, "Successfully cleaned up environment");
        return Promise.resolve();
    })
        .catch((err) => {
        console.error(err);
        return Promise.reject(err);
    });
});
const pullMaster = () => {
    colorLog({ bg: "blue", fg: "white" }, "Pulling files from Master");
    return new Promise((resolve, reject) => {
        const command = "git";
        const process = (0, child_process_1.spawn)(command, ["pull", "origin", "master"], { stdio: ["ignore", "inherit", "inherit"] });
        process.on("exit", (code) => {
            colorLog({ bg: "blue", fg: "white" }, "Successfully pulled from master");
            resolve();
        });
    });
};
const nodeInstall = () => {
    colorLog({ bg: "cyan", fg: "black" }, `Reinstalling Node Modules using ${process_1.platform.indexOf("win32") >= 0 ? "Windows Specific" : "Non-Windows"} methods`);
    return new Promise((resolve, reject) => {
        /* Windows specific NPM call */
        const command = process_1.platform.indexOf("win32") >= 0 ? "npm.cmd" : "npm";
        const process = (0, child_process_1.spawn)(command, ["install"], { stdio: ["ignore", "inherit", "inherit"] });
        process.on("exit", (code) => {
            colorLog({ bg: "cyan", fg: "black" }, "Successfully installed Node Modulenode s");
            resolve();
        });
    });
};
colorLog({ bg: "white", fg: "black" }, "Beginning Environment Reset");
const resetEnvironment = () => {
    return removeAll(pathList)
        .then(() => __awaiter(void 0, void 0, void 0, function* () {
        return yield pullMaster().catch((err) => {
            colorLog({ bg: "red", fg: "white" }, "Failed to pull from master");
            colorLog({ bg: "blue", fg: "white" }, err);
        });
    }))
        .then(() => __awaiter(void 0, void 0, void 0, function* () {
        return yield nodeInstall().catch((err) => {
            colorLog({ bg: "red", fg: "white" }, "Failed to reinstall Node Packages");
            colorLog({ bg: "none", fg: "none" }, err);
        });
    }))
        .then(() => {
        colorLog({ bg: "green", fg: "black" }, "Environment Reset Complete");
        return Promise.resolve();
    })
        .catch((err) => {
        colorLog({ bg: "red", fg: "white" }, "Failed to reset environment");
        console.error(err);
        throw err;
    });
};
resetEnvironment()
    .then(() => {
    return Promise.resolve();
})
    .catch((err) => {
    console.error(err);
    return Promise.reject(err);
});
;
